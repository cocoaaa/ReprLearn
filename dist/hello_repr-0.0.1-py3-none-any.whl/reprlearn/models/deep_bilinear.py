# Deep Bilinear Tranformation
# Paper: Learning Deep Bilinear Transformation for Fine-grained Image Representation
# Link: https://proceedings.neurips.cc/paper/2019/file/959ef477884b6ac2241b19ee4fb776ae-Paper.pdf