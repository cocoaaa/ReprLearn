def data_fn():
    print("src.data.__init__.py")
# data_fn()