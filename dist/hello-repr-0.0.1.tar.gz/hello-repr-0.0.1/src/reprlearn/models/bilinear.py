# Implementation of the Symmetric and Asymmetric bilinear models in Tenanbaum2000
class Bilinear():
    def __init__(self):
        pass
    
    
class SymBilinear():
    def __init__(self):
        pass
    def descr(self):
        pass
class DeepSymBilinear():
    def __init__(self):
        pass

class AsymBilinear():
    def __init__(self):
        pass
    def descr(self):
        pass
    