from typing import List, Callable, Union, Any, TypeVar, Tuple, Dict
# from torch import tensor as Tensor
from torch import nn
Tensor = TypeVar('torch.tensor')